# E.I.M.E.R.S. HumanAI Mathematics - v0.1.0

A governed ledger for human + AI discovery. AI and code generate the work;
independent checkers judge it; a named human approves every step up the
evidence ladder; every change is a hash-chained, append-only event.

Standard library only. Python 3.9 or newer (tested on 3.9.25 and 3.13).
No install needed: run from this folder with `python3 -m eimers_hm`.

## The evidence ladder

| Rung | Supported by passing evidence of kind |
|---|---|
| CLAIMED | (start) |
| LOCATED | located, receipt, code_review, lean, replication, schema |
| CODE_CONFIRMED | code_review, receipt, lean, replication |
| SCHEMA_VERIFIED | schema |
| RUNTIME_VERIFIED | lean pass, or a receipt marked --runtime with exit 0 |
| INDEPENDENTLY_VALIDATED | replication with two different implementations (claim must be CODE_CONFIRMED first) |

Rules the tool enforces:

- Promotion needs passing evidence, a named approver and the exact phrase
  `PROMOTE <id> TO <RUNG>`.
- A failed check puts the claim on HOLD automatically (fail closed).
- HOLD, REJECTED and SUPERSEDED claims cannot be promoted.
- A founder override (`--override-reason`) skips only the evidence rule; it is
  recorded and listed in every report.
- Corrections keep the original statement, the reason and who changed it.
- The overclaim guard flags proof wording below RUNTIME_VERIFIED,
  "independent" wording below INDEPENDENTLY_VALIDATED, and any statement that
  reads as settling a famous open problem without a stated scope.
- The ledger refuses UPDATE and DELETE; `verify` recomputes every hash.

## Quick start

```bash
cd eimers_hm_v0
bash seed_tonight.sh cpoq_ledger.sqlite
python3 -m eimers_hm --db cpoq_ledger.sqlite list
python3 -m eimers_hm --db cpoq_ledger.sqlite report --out report.md
```

## Promote on your Mac (example: ClimbExit)

The Lean checker reads your real build log and exit code. The log must
include the `#print axioms` lines.

```bash
python3 -m eimers_hm --db cpoq_ledger.sqlite check-lean --actor joshua-mac \
  --claim climb-exit --log ~/Downloads/Lean.log --exit-code-file ~/Downloads/lean_exit_code.txt
python3 -m eimers_hm --db cpoq_ledger.sqlite promote --actor joshua \
  --id climb-exit --to RUNTIME_VERIFIED --approved-by "Joshua Eimers" \
  --confirm "PROMOTE climb-exit TO RUNTIME_VERIFIED"
```

Check the log path first: it must be the log from ClimbExit, not another run.

## Record Gate 15 when it finishes

```bash
python3 -m eimers_hm --db cpoq_ledger.sqlite check-lean --actor joshua-mac \
  --claim gate15-kernel --log ~/Downloads/gate15/gate15_build.log --exit-code <code>
python3 -m eimers_hm --db cpoq_ledger.sqlite status --actor joshua \
  --id gate15-kernel --status OPEN --reason "build finished"
```

Then promote with the phrase, as above.

## Record a replication

```bash
python3 -m eimers_hm --db cpoq_ledger.sqlite check-replication --actor joshua \
  --claim seg33-depth27-list --a q27_certified.txt --b claude_q27.txt \
  --impl-a "Joshua generator" --impl-b "Claude tree.py"
```

## Keep a receipt for any run

```bash
python3 -m eimers_hm --db cpoq_ledger.sqlite run --actor joshua-mac \
  --claim v88-api --runtime --input collatz_v87.sqlite -- python3 test_v88.py
```

Output is saved under `receipts/<id>/` next to the ledger.

## Commands

`init`, `add-claim`, `list`, `show`, `evidence`, `check-lean`,
`check-replication`, `run`, `promote`, `status`, `correct`, `handoff`,
`verify`, `report`. Add `--help` to any of them.

## Limits of v0 (honest list)

- `--actor` is typed, not signed: it records who says they acted. Tie it to
  E.I.M.E.R.S. sign-in before using it with other people.
- The hash chain shows tampering inside the file. Someone who rewrites the
  whole file can rebuild a valid chain; publish the latest hash elsewhere
  (for example in E.I.M.E.R.S. Task & Evidence) to close that gap.
- No web screen yet; command line only.
- Checkers so far: Lean logs and two-file replication. Others (SMT, property
  tests, notebook reruns) plug in the same way.
- The tool does not discover anything. It makes results trustworthy and
  repeatable.
