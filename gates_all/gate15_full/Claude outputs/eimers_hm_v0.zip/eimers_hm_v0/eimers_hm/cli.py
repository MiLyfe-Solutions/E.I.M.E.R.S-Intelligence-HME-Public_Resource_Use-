"""Command line for E.I.M.E.R.S. HumanAI Mathematics.

Run `python3 -m eimers_hm --help`. Every write needs --actor (who did it).
"""

import argparse
import json
import os
import sys

from . import RUNGS, __version__
from .checkers import check_lean, check_replication, DEFAULT_ALLOWED_AXIOMS
from .gate import check_promotion, confirmation_phrase, guard, supporting_evidence
from .ledger import Ledger
from .receipts import run_with_receipt
from .report import build_report


def _ledger(args):
    return Ledger(args.db)


def _print(obj):
    print(json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False))


def cmd_init(args):
    led = _ledger(args)
    ok, _, n = led.verify_chain()
    _print({"db": os.path.abspath(args.db), "events": n, "chain_ok": ok})
    return 0


def cmd_add_claim(args):
    led = _ledger(args)
    ev = led.add_claim(args.id, args.statement, args.scope or "", args.actor)
    flags = guard(args.statement, "CLAIMED")
    _print({"added": args.id, "event": ev["seq"], "overclaim_flags": flags})
    return 0


def cmd_list(args):
    led = _ledger(args)
    for c in sorted(led.state()["claims"].values(), key=lambda c: c["id"]):
        flag = " [OVERCLAIM]" if guard(c["statement"], c["rung"]) else ""
        print("%-28s %-24s %-9s %s%s" % (c["id"], c["rung"], c["status"],
                                          c["statement"][:70], flag))
    return 0


def cmd_show(args):
    _print(_ledger(args).claim(args.id))
    return 0


def cmd_evidence(args):
    led = _ledger(args)
    details = {"note": args.note}
    if args.ref:
        details["ref"] = args.ref
    ev = led.add_evidence(args.claim, args.kind, not args.failed, details, args.actor)
    _print({"evidence_event": ev["seq"], "passed": not args.failed})
    return 0


def cmd_check_lean(args):
    led = _ledger(args)
    with open(args.log, "r", encoding="utf-8", errors="replace") as f:
        text = f.read()
    if args.exit_code_file:
        with open(args.exit_code_file) as f:
            exit_code = int(f.read().strip())
    else:
        exit_code = args.exit_code
    allowed = tuple(args.allow_axiom) if args.allow_axiom else DEFAULT_ALLOWED_AXIOMS
    res = check_lean(text, exit_code, allowed_axioms=allowed,
                     require_axioms=not args.no_require_axioms)
    from .checkers import sha256_file
    res["log_path"] = os.path.abspath(args.log)
    res["log_sha256"] = sha256_file(args.log)
    if args.note:
        res["note"] = args.note
    ev = led.add_evidence(args.claim, "lean", res["passed"], res, args.actor)
    _print({"evidence_event": ev["seq"], "passed": res["passed"], "reasons": res["reasons"],
            "theorems": res["theorems"], "axioms_used": res["axioms_used"]})
    return 0 if res["passed"] else 2


def cmd_check_replication(args):
    led = _ledger(args)
    res = check_replication(args.a, args.b, args.impl_a, args.impl_b, args.sort_lines)
    if args.note:
        res["note"] = args.note
    ev = led.add_evidence(args.claim, "replication", res["passed"], res, args.actor)
    _print({"evidence_event": ev["seq"], "passed": res["passed"], "reasons": res["reasons"],
            "sha256_a": res["sha256_a"], "sha256_b": res["sha256_b"]})
    return 0 if res["passed"] else 2


def cmd_run(args):
    led = _ledger(args)
    if not args.cmd:
        print("give the command after --", file=sys.stderr)
        return 1
    store = os.path.dirname(os.path.abspath(args.db))
    body = run_with_receipt(args.cmd, store, cwd=args.cwd, inputs=args.input or (),
                            timeout=args.timeout)
    body["runtime"] = bool(args.runtime)
    led.append("receipt", args.actor, body)
    out = {"receipt_id": body["receipt_id"], "exit_code": body["exit_code"],
           "duration_s": body["duration_s"], "stdout": body["stdout_path"]}
    if args.claim:
        ev = led.add_evidence(args.claim, "receipt", body["exit_code"] == 0, body, args.actor)
        out["evidence_event"] = ev["seq"]
    _print(out)
    return 0 if body["exit_code"] == 0 else 2


def cmd_promote(args):
    led = _ledger(args)
    c = led.claim(args.id)
    reasons = check_promotion(c, args.to, args.approved_by, args.confirm, args.override_reason)
    if reasons:
        _print({"promoted": False, "blocked_by": reasons,
                "confirmation_phrase": confirmation_phrase(args.id, args.to)})
        return 3
    used = [e["seq"] for e in supporting_evidence(c, args.to)]
    ev = led.append("promoted", args.actor, {
        "claim_id": args.id, "from": c["rung"], "to": args.to,
        "approved_by": args.approved_by, "evidence_events": used,
        "override_reason": args.override_reason or None})
    flags = guard(c["statement"], args.to)
    _print({"promoted": True, "event": ev["seq"], "from": c["rung"], "to": args.to,
            "evidence_events": used, "override": bool(args.override_reason),
            "overclaim_flags": flags})
    return 0


def cmd_status(args):
    led = _ledger(args)
    ev = led.set_status(args.id, args.status, args.reason, args.actor)
    _print({"claim": args.id, "status": args.status, "event": ev["seq"]})
    return 0


def cmd_correct(args):
    led = _ledger(args)
    ev = led.correct(args.id, args.statement, args.reason, args.evidence or "", args.actor)
    _print({"corrected": args.id, "event": ev["seq"]})
    return 0


def cmd_handoff(args):
    led = _ledger(args)
    payload = {"summary": args.summary, "open_tasks": args.open or [],
               "do_not_repeat": args.do_not_repeat or [],
               "next_safe_action": args.next or ""}
    ev = led.handoff(payload, args.actor)
    _print({"handoff_event": ev["seq"]})
    return 0


def cmd_verify(args):
    ok, bad, n = _ledger(args).verify_chain()
    _print({"chain_ok": ok, "events": n, "first_bad_event": bad})
    return 0 if ok else 4


def cmd_report(args):
    text = build_report(_ledger(args))
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(text + "\n")
        print(os.path.abspath(args.out))
    else:
        print(text)
    return 0


def build_parser():
    p = argparse.ArgumentParser(prog="eimers_hm",
                                description="E.I.M.E.R.S. HumanAI Mathematics v%s" % __version__)
    p.add_argument("--db", default="eimers_hm.sqlite", help="ledger file (default: %(default)s)")
    sub = p.add_subparsers(dest="command")

    def w(sp):  # write commands need an actor
        sp.add_argument("--actor", required=True, help="who is doing this (person or AI worker id)")
        return sp

    sp = sub.add_parser("init", help="create or open the ledger and check its chain")
    sp.set_defaults(func=cmd_init)

    sp = w(sub.add_parser("add-claim", help="record a new claim at CLAIMED"))
    sp.add_argument("--id", required=True)
    sp.add_argument("--statement", required=True)
    sp.add_argument("--scope")
    sp.set_defaults(func=cmd_add_claim)

    sp = sub.add_parser("list", help="list claims with rung and status")
    sp.set_defaults(func=cmd_list)

    sp = sub.add_parser("show", help="show one claim with its evidence and history")
    sp.add_argument("--id", required=True)
    sp.set_defaults(func=cmd_show)

    sp = w(sub.add_parser("evidence", help="attach a manual evidence note"))
    sp.add_argument("--claim", required=True)
    sp.add_argument("--kind", required=True,
                    choices=["located", "code_review", "schema", "receipt", "other"])
    sp.add_argument("--note", required=True)
    sp.add_argument("--ref", help="file path, URL or hash the note points to")
    sp.add_argument("--failed", action="store_true", help="record as a failed check (puts claim on HOLD)")
    sp.set_defaults(func=cmd_evidence)

    sp = w(sub.add_parser("check-lean", help="judge a Lean build log and attach the result"))
    sp.add_argument("--claim", required=True)
    sp.add_argument("--log", required=True)
    g = sp.add_mutually_exclusive_group(required=True)
    g.add_argument("--exit-code", type=int)
    g.add_argument("--exit-code-file")
    sp.add_argument("--allow-axiom", action="append",
                    help="allowed axiom (repeat); default propext, Quot.sound, Classical.choice")
    sp.add_argument("--no-require-axioms", action="store_true")
    sp.add_argument("--note")
    sp.set_defaults(func=cmd_check_lean)

    sp = w(sub.add_parser("check-replication", help="compare two independent results"))
    sp.add_argument("--claim", required=True)
    sp.add_argument("--a", required=True)
    sp.add_argument("--b", required=True)
    sp.add_argument("--impl-a", required=True)
    sp.add_argument("--impl-b", required=True)
    sp.add_argument("--sort-lines", action="store_true")
    sp.add_argument("--note")
    sp.set_defaults(func=cmd_check_replication)

    sp = w(sub.add_parser("run", help="run a command and keep a receipt: run [opts] -- cmd args"))
    sp.add_argument("--claim")
    sp.add_argument("--input", action="append", help="input file to hash (repeat)")
    sp.add_argument("--cwd")
    sp.add_argument("--timeout", type=float)
    sp.add_argument("--runtime", action="store_true",
                    help="mark this run as runtime evidence (can support RUNTIME_VERIFIED)")
    sp.add_argument("cmd", nargs=argparse.REMAINDER)
    sp.set_defaults(func=cmd_run)

    sp = w(sub.add_parser("promote", help="move a claim up one or more rungs (human gate)"))
    sp.add_argument("--id", required=True)
    sp.add_argument("--to", required=True, choices=RUNGS)
    sp.add_argument("--approved-by", required=True)
    sp.add_argument("--confirm", required=True, help='exact phrase: "PROMOTE <id> TO <RUNG>"')
    sp.add_argument("--override-reason", help="founder override: promote without supporting evidence")
    sp.set_defaults(func=cmd_promote)

    sp = w(sub.add_parser("status", help="set OPEN, HOLD, REJECTED or SUPERSEDED"))
    sp.add_argument("--id", required=True)
    sp.add_argument("--status", required=True, choices=["OPEN", "HOLD", "REJECTED", "SUPERSEDED"])
    sp.add_argument("--reason", required=True)
    sp.set_defaults(func=cmd_status)

    sp = w(sub.add_parser("correct", help="correct a statement; the original is kept"))
    sp.add_argument("--id", required=True)
    sp.add_argument("--statement", required=True)
    sp.add_argument("--reason", required=True)
    sp.add_argument("--evidence")
    sp.set_defaults(func=cmd_correct)

    sp = w(sub.add_parser("handoff", help="record a session handoff"))
    sp.add_argument("--summary", required=True)
    sp.add_argument("--open", action="append")
    sp.add_argument("--do-not-repeat", action="append")
    sp.add_argument("--next")
    sp.set_defaults(func=cmd_handoff)

    sp = sub.add_parser("verify", help="recompute the hash chain")
    sp.set_defaults(func=cmd_verify)

    sp = sub.add_parser("report", help="write a markdown report from the ledger")
    sp.add_argument("--out")
    sp.set_defaults(func=cmd_report)
    return p


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, "func", None):
        parser.print_help()
        return 1
    if getattr(args, "cmd", None) and args.cmd and args.cmd[0] == "--":
        args.cmd = args.cmd[1:]
    try:
        return args.func(args)
    except (KeyError, ValueError) as exc:
        print("error: %s" % exc, file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
