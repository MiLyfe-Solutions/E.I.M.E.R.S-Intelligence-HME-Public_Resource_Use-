"""Append-only, hash-chained event ledger on SQLite.

Every change is an event. Nothing is updated or deleted: SQLite triggers
refuse UPDATE and DELETE on the events table. Current state (claims, rungs,
statuses) is rebuilt by replaying events in order.
"""

import hashlib
import json
import os
import sqlite3
from datetime import datetime, timezone

from . import RUNGS, rung_index

GENESIS = "0" * 64

SCHEMA = """
CREATE TABLE IF NOT EXISTS events (
    seq       INTEGER PRIMARY KEY AUTOINCREMENT,
    ts        TEXT NOT NULL,
    kind      TEXT NOT NULL,
    actor     TEXT NOT NULL,
    payload   TEXT NOT NULL,
    prev_hash TEXT NOT NULL,
    hash      TEXT NOT NULL UNIQUE
);
CREATE TRIGGER IF NOT EXISTS events_no_update BEFORE UPDATE ON events
BEGIN SELECT RAISE(ABORT, 'ledger is append-only'); END;
CREATE TRIGGER IF NOT EXISTS events_no_delete BEFORE DELETE ON events
BEGIN SELECT RAISE(ABORT, 'ledger is append-only'); END;
"""


def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def event_hash(prev_hash, ts, kind, actor, payload_json):
    h = hashlib.sha256()
    h.update("|".join([prev_hash, ts, kind, actor, payload_json]).encode("utf-8"))
    return h.hexdigest()


def now_utc():
    fixed = os.environ.get("EIMERS_HM_FIXED_TS")
    if fixed:
        return fixed
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


class Ledger(object):
    def __init__(self, path):
        self.path = path
        self.conn = sqlite3.connect(path)
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    def close(self):
        self.conn.close()

    # ---- low level -------------------------------------------------------
    def last_hash(self):
        row = self.conn.execute("SELECT hash FROM events ORDER BY seq DESC LIMIT 1").fetchone()
        return row[0] if row else GENESIS

    def append(self, kind, actor, payload):
        if not actor:
            raise ValueError("every event needs an actor")
        ts = now_utc()
        pj = canonical(payload)
        prev = self.last_hash()
        h = event_hash(prev, ts, kind, actor, pj)
        cur = self.conn.execute(
            "INSERT INTO events (ts, kind, actor, payload, prev_hash, hash) VALUES (?,?,?,?,?,?)",
            (ts, kind, actor, pj, prev, h),
        )
        self.conn.commit()
        return {"seq": cur.lastrowid, "ts": ts, "kind": kind, "actor": actor,
                "payload": payload, "prev_hash": prev, "hash": h}

    def events(self):
        rows = self.conn.execute(
            "SELECT seq, ts, kind, actor, payload, prev_hash, hash FROM events ORDER BY seq"
        ).fetchall()
        out = []
        for seq, ts, kind, actor, payload, prev, h in rows:
            out.append({"seq": seq, "ts": ts, "kind": kind, "actor": actor,
                        "payload": json.loads(payload), "payload_json": payload,
                        "prev_hash": prev, "hash": h})
        return out

    def verify_chain(self):
        """Recompute every hash. Returns (ok, first_bad_seq_or_None, count)."""
        prev = GENESIS
        evs = self.events()
        for e in evs:
            if e["prev_hash"] != prev:
                return False, e["seq"], len(evs)
            if event_hash(prev, e["ts"], e["kind"], e["actor"], e["payload_json"]) != e["hash"]:
                return False, e["seq"], len(evs)
            prev = e["hash"]
        return True, None, len(evs)

    # ---- state replay ------------------------------------------------------
    def state(self):
        claims = {}
        handoffs = []
        receipts = {}
        for e in self.events():
            k, p = e["kind"], e["payload"]
            ref = {"seq": e["seq"], "ts": e["ts"], "actor": e["actor"], "hash": e["hash"]}
            if k == "claim_added":
                claims[p["id"]] = {
                    "id": p["id"], "statement": p["statement"],
                    "original_statement": p["statement"], "scope": p.get("scope", ""),
                    "rung": "CLAIMED", "status": "OPEN", "evidence": [],
                    "history": [dict(ref, event="added")], "overrides": [],
                    "corrections": [],
                }
            elif k == "evidence_added":
                c = claims[p["claim_id"]]
                c["evidence"].append(dict(p, **{"seq": e["seq"], "hash": e["hash"]}))
            elif k == "promoted":
                c = claims[p["claim_id"]]
                c["rung"] = p["to"]
                c["history"].append(dict(ref, event="promoted", frm=p["from"], to=p["to"],
                                         approved_by=p.get("approved_by"),
                                         override=p.get("override_reason")))
                if p.get("override_reason"):
                    c["overrides"].append(dict(ref, reason=p["override_reason"], to=p["to"]))
            elif k == "status_changed":
                c = claims[p["claim_id"]]
                c["status"] = p["status"]
                c["history"].append(dict(ref, event="status", status=p["status"],
                                         reason=p.get("reason")))
            elif k == "corrected":
                c = claims[p["claim_id"]]
                c["corrections"].append(dict(ref, original=p["original"],
                                             corrected=p["corrected"], reason=p["reason"],
                                             evidence=p.get("evidence", "")))
                c["statement"] = p["corrected"]
            elif k == "receipt":
                receipts[p["receipt_id"]] = dict(p, seq=e["seq"], hash=e["hash"])
            elif k == "handoff":
                handoffs.append(dict(p, seq=e["seq"], ts=e["ts"], actor=e["actor"],
                                     hash=e["hash"]))
        return {"claims": claims, "handoffs": handoffs, "receipts": receipts}

    # ---- convenience ---------------------------------------------------------
    def claim(self, claim_id):
        st = self.state()
        if claim_id not in st["claims"]:
            raise KeyError("no such claim: %s" % claim_id)
        return st["claims"][claim_id]

    def add_claim(self, claim_id, statement, scope, actor):
        if claim_id in self.state()["claims"]:
            raise ValueError("claim id already exists: %s" % claim_id)
        return self.append("claim_added", actor,
                           {"id": claim_id, "statement": statement, "scope": scope})

    def add_evidence(self, claim_id, kind, passed, details, actor):
        self.claim(claim_id)  # existence check
        ev = self.append("evidence_added", actor,
                         {"claim_id": claim_id, "kind": kind, "passed": bool(passed),
                          "details": details})
        if not passed:
            # Fail closed: a failed check puts the claim on HOLD.
            self.append("status_changed", actor,
                        {"claim_id": claim_id, "status": "HOLD",
                         "reason": "failed %s check (event %d)" % (kind, ev["seq"])})
        return ev

    def set_status(self, claim_id, status, reason, actor):
        self.claim(claim_id)
        return self.append("status_changed", actor,
                           {"claim_id": claim_id, "status": status, "reason": reason})

    def correct(self, claim_id, corrected, reason, evidence, actor):
        c = self.claim(claim_id)
        return self.append("corrected", actor,
                           {"claim_id": claim_id, "original": c["statement"],
                            "corrected": corrected, "reason": reason, "evidence": evidence})

    def handoff(self, payload, actor):
        return self.append("handoff", actor, payload)


def higher(a, b):
    return rung_index(a) > rung_index(b)


__all__ = ["Ledger", "GENESIS", "RUNGS", "higher", "canonical"]
