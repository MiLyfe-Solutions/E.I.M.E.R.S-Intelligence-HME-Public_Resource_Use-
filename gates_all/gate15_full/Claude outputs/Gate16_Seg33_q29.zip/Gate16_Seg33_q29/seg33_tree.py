#!/usr/bin/env python3
"""Independent Segment 33 split tree (Terras-style), exact integers.

Family: n = r + 2^B * t (t >= 0). State after some shortcut steps: A*t + C.
Shortcut map T: even -> n/2, odd -> (3n+1)/2. Parity of A*t+C is fixed
for all t only while A is even; when A is odd we split on one more bit of t.
A family is certified when A <= 2^B and C < r: then A*t+C < r + 2^B*t for all t.

Usage: tree.py MAXDEPTH  -> prints certified mass and open leaves per depth.
"""
import sys, time
from fractions import Fraction

BASE = 3487011090801549639707
B0 = 73

def run(maxdepth, collect_open=False):
    # stack items: (depth, r, B, A, C, steps)
    stack = [(0, BASE, B0, 1 << B0, BASE, 0)]
    cert_by_depth = {}
    open_leaves = []
    open_count = [0]
    max_steps = 0
    while stack:
        d, r, B, A, C, s = stack.pop()
        while True:
            if A <= (1 << B) and C < r and s > 0:
                cert_by_depth[d] = cert_by_depth.get(d, 0) + 1
                if s > max_steps: max_steps = s
                break
            if A & 1:
                if d == maxdepth:
                    open_count[0] += 1
                    if collect_open: open_leaves.append((r - BASE) >> B0)
                    break
                # split on next bit of t: t = 2t' + bit
                stack.append((d + 1, r + (1 << B), B + 1, 2 * A, C + A, s))
                A, B, d = 2 * A, B + 1, d + 1
                continue
            if C & 1:
                A, C = 3 * A // 2, (3 * C + 1) // 2
            else:
                A, C = A // 2, C // 2
            s += 1
    return cert_by_depth, open_leaves, max_steps, open_count[0]

if __name__ == "__main__":
    D = int(sys.argv[1])
    t0 = time.time()
    cert, opn, ms, nopen = run(D, collect_open=(len(sys.argv) > 2))
    mass = sum(Fraction(c, 2 ** d) for d, c in cert.items())
    print("MAXDEPTH", D, "seconds", round(time.time() - t0, 1))
    print("certified_families", sum(cert.values()), "max_shortcut_steps", ms)
    print("certified_mass", float(mass), "open_leaves_at_maxdepth", nopen,
          "open_mass", float(Fraction(nopen, 2 ** D)), "open_exact", f"{nopen}/2^{D}")
    print("cert_by_depth", dict(sorted(cert.items())))
    if len(sys.argv) > 2:
        with open(sys.argv[2], "w") as f:
            for q in sorted(opn): f.write(f"{q}\n")
