import Lake
open Lake DSL

package gate16 where

@[default_target]
lean_lib Gate16
