#!/bin/bash
# Seed a ledger with the CPOQ records from the 2026-10-25/26 session.
# Every claim starts at CLAIMED. Evidence below is recorded as notes that
# cite the hashes and outputs seen in the session; nothing is promoted.
# Promotion is Joshua's step (see README: "Promote on your Mac").
# Usage: bash seed_tonight.sh [ledger_path]
set -e
DB="${1:-cpoq_ledger.sqlite}"
if [ -e "$DB" ]; then
  echo "refusing to overwrite existing ledger: $DB" >&2
  exit 1
fi
A="claude-session-2026-10-26"
HM="python3 -m eimers_hm --db $DB"

$HM init >/dev/null

$HM add-claim --actor "$A" --id h28-gateA \
  --statement "WordTrace w x y implies 2^(sum w) * y = 3^|w| * x + offset(w) (H28 Gate A, affine forward identity)" \
  --scope "all words w and naturals x y; Lean 4.35, core only" >/dev/null
$HM evidence --actor "$A" --claim h28-gateA --kind code_review \
  --note "H28AffineForward.lean patched (sha256 7da62745...); final calc step fixed with rw [Nat.mul_add, Nat.mul_one, Nat.pow_succ]; ac_rfl. Mac lake run exit 0 reported by Joshua." >/dev/null

$HM add-claim --actor "$A" --id h28-gateB-iff \
  --statement "WordTrace w x y holds if and only if the affine identity holds with x and y odd (H28 Gate B, wordTrace_iff_affine)" \
  --scope "FamilyDescent.lean definitions (sha256 0759107a...)" >/dev/null
$HM evidence --actor "$A" --claim h28-gateB-iff --kind code_review \
  --note "H28AffineIff.lean (sha256 7998ce88...). Mac run exit 0, log sha256 d3334b5a...; axioms propext, Classical.choice, Quot.sound reported." >/dev/null

$HM add-claim --actor "$A" --id climb-exit \
  --statement "For every k and m >= 1, k shortcut steps send 2^k*m - 1 to 3^k*m - 1; the exit is even for odd m and above the start for k >= 1" \
  --scope "ClimbExit.lean v3 (sha256 db4a604c...), namespace CPOQClimb" >/dev/null
$HM evidence --actor "$A" --claim climb-exit --kind code_review \
  --note "Mac run exit 0; step_one, climb_exit, exit_even, two_pow_lt_three_pow, exit_above each depend on axioms [propext, Quot.sound] (screenshot 2026-10-26)." >/dev/null

$HM add-claim --actor "$A" --id collatz-reduction \
  --statement "If every number above 1 eventually drops below itself, then every positive number reaches 1 (reduction lemma)" \
  --scope "CollatzReduction.lean (sha256 3d593967...), reaches_one_of_every_number_drops" >/dev/null
$HM evidence --actor "$A" --claim collatz-reduction --kind code_review \
  --note "Mac run exit 0, log sha256 dd1a2125...; axioms propext, Quot.sound." >/dev/null

$HM add-claim --actor "$A" --id seg33-depth27-list \
  --statement "At split depth 27, 1,348,864 residue families of Segment 33 each drop below their start; their share is 1 - 64,541/2^20 = 93.8449%" \
  --scope "Segment 33: n = 3487011090801549639707 + 2^73 q; list q27_certified.txt sha256 e746f486..." >/dev/null
$HM evidence --actor "$A" --claim seg33-depth27-list --kind code_review \
  --note "Joshua's generator list and Claude's independent tree.py (sha256 72211a37...) gave byte-identical lists (e746f486...); 1,800 direct spot checks, 0 failures. Run check-replication on both files to record this formally." >/dev/null

$HM add-claim --actor "$A" --id gate15-kernel \
  --statement "Lean kernel checks all 1,349 Gate 15 chunks: every depth-27 Segment 33 family drops within 163 ordinary steps" \
  --scope "~/Downloads/gate15, Gate15/All.lean imports 1,349 chunks" >/dev/null
$HM evidence --actor "$A" --claim gate15-kernel --kind located \
  --note "At 01:02 2026-10-26: 1,288 of 1,349 chunk .olean files built; 0 error or sorry lines in log; All.lean imports 1,349 chunks. Build not finished." >/dev/null
$HM status --actor "$A" --id gate15-kernel --status HOLD \
  --reason "build in progress; needs exit code 0 and #print axioms with no sorryAx" >/dev/null

$HM add-claim --actor "$A" --id seg33-leftover \
  --statement "Splitting Segment 33 deeper leaves an uncertified share of 4.590% at depth 32; open pieces roughly double per level, so splitting alone does not finish" \
  --scope "seg33 tree.py depths 20-32" >/dev/null
$HM evidence --actor "$A" --claim seg33-leftover --kind code_review \
  --note "tree.py depth 32: 197,128,825 open pieces = 197128825/2^32; profile.py: depth-27 open pieces all at s=100. Python computation, not kernel-checked." >/dev/null

$HM add-claim --actor "$A" --id v88-api \
  --statement "V88 API test suite passes 21 of 21 against collatz_v87.sqlite without changing it" \
  --scope "collatz_v88_api.py, test_v88.py, database sha256 dd5b7330...; lives outside apex-engine-main" >/dev/null
$HM evidence --actor "$A" --claim v88-api --kind receipt \
  --note "Run in Claude's sandbox venv 2026-10-25: 21/21 PASS, database hash unchanged. Not yet rerun on the Mac." >/dev/null

$HM add-claim --actor "$A" --id collatz-universal \
  --statement "The Collatz conjecture holds for every positive integer" \
  --scope "open problem; Stage 2 (every number drops below its start) is not established" >/dev/null
$HM status --actor "$A" --id collatz-universal --status HOLD --reason "HOLD_UNPROVEN" >/dev/null

$HM handoff --actor "$A" \
  --summary "Seeded from the 2026-10-25/26 session. All claims at CLAIMED; Lean results recorded as notes, not yet checked by this tool." \
  --open "Run check-lean on the real Mac logs, then promote with your confirmation phrase" \
  --open "Finish Gate 15; record exit code and axioms" \
  --open "Record the q27 replication with check-replication on both list files" \
  --do-not-repeat "Do not promote from notes alone; notes support LOCATED or CODE_CONFIRMED only" \
  --next "check-lean on ClimbExit Lean.log" >/dev/null

$HM verify
echo "seeded: $DB"
