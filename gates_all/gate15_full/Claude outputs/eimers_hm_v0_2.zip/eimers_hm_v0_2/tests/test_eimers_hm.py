import os
import sqlite3
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from eimers_hm.checkers import check_lean, check_replication  # noqa: E402
from eimers_hm.cli import main  # noqa: E402
from eimers_hm.gate import check_promotion, confirmation_phrase, guard  # noqa: E402
from eimers_hm.ledger import Ledger  # noqa: E402
from eimers_hm.report import build_report  # noqa: E402

CLEAN_LOG = """USING=/Users/x/ClimbExit.lean
'CPOQClimb.step_one' depends on axioms: [propext, Quot.sound]
'CPOQClimb.climb_exit' depends on axioms: [propext, Quot.sound]
'CPOQClimb.exit_even' depends on axioms: [propext, Quot.sound]
"""


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.db = os.path.join(self.tmp, "t.sqlite")
        self.led = Ledger(self.db)

    def tearDown(self):
        self.led.close()

    def write(self, name, data):
        p = os.path.join(self.tmp, name)
        with open(p, "w") as f:
            f.write(data)
        return p


class TestLedger(Base):
    def test_chain_intact_and_append_only(self):
        self.led.add_claim("c1", "x drops", "", "joshua")
        self.led.add_evidence("c1", "located", True, {"note": "n"}, "joshua")
        ok, bad, n = self.led.verify_chain()
        self.assertTrue(ok)
        self.assertEqual(n, 2)
        with self.assertRaises(sqlite3.DatabaseError):
            self.led.conn.execute("UPDATE events SET actor='x' WHERE seq=1")
        with self.assertRaises(sqlite3.DatabaseError):
            self.led.conn.execute("DELETE FROM events WHERE seq=1")

    def test_tamper_detected(self):
        self.led.add_claim("c1", "x drops", "", "joshua")
        self.led.add_claim("c2", "y drops", "", "joshua")
        self.led.conn.execute("DROP TRIGGER events_no_update")
        self.led.conn.execute("UPDATE events SET payload=replace(payload,'x drops','x rises') WHERE seq=1")
        self.led.conn.commit()
        ok, bad, _ = self.led.verify_chain()
        self.assertFalse(ok)
        self.assertEqual(bad, 1)

    def test_failed_evidence_puts_claim_on_hold(self):
        self.led.add_claim("c1", "x", "", "joshua")
        self.led.add_evidence("c1", "lean", False, {"reasons": ["exit 1"]}, "claude")
        self.assertEqual(self.led.claim("c1")["status"], "HOLD")

    def test_correction_keeps_original(self):
        self.led.add_claim("c1", "old words", "", "joshua")
        self.led.correct("c1", "new words", "typo", "", "joshua")
        c = self.led.claim("c1")
        self.assertEqual(c["statement"], "new words")
        self.assertEqual(c["original_statement"], "old words")
        self.assertEqual(c["corrections"][0]["original"], "old words")

    def test_duplicate_id_refused(self):
        self.led.add_claim("c1", "x", "", "joshua")
        with self.assertRaises(ValueError):
            self.led.add_claim("c1", "y", "", "joshua")


class TestLeanChecker(unittest.TestCase):
    def test_clean(self):
        r = check_lean(CLEAN_LOG, 0)
        self.assertTrue(r["passed"], r["reasons"])
        self.assertEqual(r["theorems"], 3)

    def test_nonzero_exit(self):
        self.assertFalse(check_lean(CLEAN_LOG, 1)["passed"])

    def test_sorry_axiom(self):
        log = CLEAN_LOG + "'X.bad' depends on axioms: [propext, sorryAx]\n"
        r = check_lean(log, 0)
        self.assertFalse(r["passed"])
        self.assertIn("sorryAx appears in axioms", r["reasons"])

    def test_sorry_warning(self):
        log = CLEAN_LOG + "warning: ./F.lean:3:8: declaration uses 'sorry'\n"
        self.assertFalse(check_lean(log, 0)["passed"])

    def test_error_line(self):
        log = CLEAN_LOG + "error: ./F.lean:9:2: unknown identifier\n"
        self.assertFalse(check_lean(log, 0)["passed"])

    def test_unexpected_axiom(self):
        log = "'X.t' depends on axioms: [propext, myAxiom]\n"
        r = check_lean(log, 0)
        self.assertFalse(r["passed"])
        self.assertTrue(any("myAxiom" in x for x in r["reasons"]))

    def test_no_axioms_output(self):
        self.assertFalse(check_lean("Build completed successfully.\n", 0)["passed"])
        self.assertTrue(check_lean("Build completed successfully.\n", 0,
                                   require_axioms=False)["passed"])

    def test_no_axioms_theorem(self):
        r = check_lean("'X.t' does not depend on any axioms\n", 0)
        self.assertTrue(r["passed"])


class TestReplication(Base):
    def test_match_independent(self):
        a = self.write("a.txt", "1\n2\n3\n")
        b = self.write("b.txt", "1\n2\n3\n")
        self.assertTrue(check_replication(a, b, "gen.py (Joshua)", "tree.py (Claude)")["passed"])

    def test_same_impl_is_rerun(self):
        a = self.write("a.txt", "1\n")
        b = self.write("b.txt", "1\n")
        r = check_replication(a, b, "tree.py", "tree.py")
        self.assertFalse(r["passed"])

    def test_mismatch(self):
        a = self.write("a.txt", "1\n2\n")
        b = self.write("b.txt", "1\n3\n")
        self.assertFalse(check_replication(a, b, "p", "q")["passed"])

    def test_sort_lines(self):
        a = self.write("a.txt", "2\n1\n")
        b = self.write("b.txt", "1\n2\n")
        self.assertFalse(check_replication(a, b, "p", "q")["passed"])
        self.assertTrue(check_replication(a, b, "p", "q", sort_lines=True)["passed"])


class TestGate(Base):
    def _claim(self):
        self.led.add_claim("c1", "every lot in the list drops within 163 steps", "", "joshua")
        return self.led.claim("c1")

    def test_needs_evidence_phrase_approver(self):
        c = self._claim()
        r = check_promotion(c, "RUNTIME_VERIFIED", "", "nope")
        self.assertTrue(any("approver" in x for x in r))
        self.assertTrue(any("confirmation phrase" in x for x in r))
        self.assertTrue(any("no passing evidence" in x for x in r))

    def test_lean_pass_allows_runtime(self):
        self._claim()
        self.led.add_evidence("c1", "lean", True, check_lean(CLEAN_LOG, 0), "claude")
        c = self.led.claim("c1")
        r = check_promotion(c, "RUNTIME_VERIFIED", "Joshua",
                            confirmation_phrase("c1", "RUNTIME_VERIFIED"))
        self.assertEqual(r, [])

    def test_hold_blocks(self):
        self._claim()
        self.led.add_evidence("c1", "lean", True, check_lean(CLEAN_LOG, 0), "claude")
        self.led.set_status("c1", "HOLD", "waiting", "joshua")
        r = check_promotion(self.led.claim("c1"), "RUNTIME_VERIFIED", "Joshua",
                            confirmation_phrase("c1", "RUNTIME_VERIFIED"))
        self.assertTrue(any("HOLD" in x for x in r))

    def test_independent_needs_code_confirmed_first(self):
        self._claim()
        self.led.add_evidence("c1", "replication", True,
                              {"independent": True, "reasons": []}, "claude")
        r = check_promotion(self.led.claim("c1"), "INDEPENDENTLY_VALIDATED", "Joshua",
                            confirmation_phrase("c1", "INDEPENDENTLY_VALIDATED"))
        self.assertTrue(any("CODE_CONFIRMED" in x for x in r))

    def test_override_bypasses_evidence_only(self):
        c = self._claim()
        r = check_promotion(c, "LOCATED", "Joshua", confirmation_phrase("c1", "LOCATED"),
                            override_reason="seen on screen")
        self.assertEqual(r, [])


class TestGuard(unittest.TestCase):
    def test_proof_wording_needs_runtime(self):
        self.assertTrue(guard("Gate 15 is proven", "CODE_CONFIRMED"))
        self.assertFalse(guard("Gate 15 is proven", "RUNTIME_VERIFIED"))

    def test_open_problem_unscoped(self):
        self.assertTrue(any("collatz" in f for f in guard("This proves Collatz", "INDEPENDENTLY_VALIDATED")))

    def test_open_problem_scoped(self):
        flags = guard("Every Collatz family in Segment 33 list drops; proven in Lean",
                      "RUNTIME_VERIFIED")
        self.assertEqual(flags, [])


class TestCLI(Base):
    def test_end_to_end(self):
        db = os.path.join(self.tmp, "cli.sqlite")
        log = self.write("lean.log", CLEAN_LOG)
        self.assertEqual(main(["--db", db, "add-claim", "--actor", "joshua", "--id", "climb",
                               "--statement", "climb exit formula holds for all k"]), 0)
        self.assertEqual(main(["--db", db, "check-lean", "--actor", "mac", "--claim", "climb",
                               "--log", log, "--exit-code", "0"]), 0)
        self.assertEqual(main(["--db", db, "promote", "--actor", "joshua", "--id", "climb",
                               "--to", "RUNTIME_VERIFIED", "--approved-by", "Joshua",
                               "--confirm", "PROMOTE climb TO RUNTIME_VERIFIED"]), 0)
        self.assertEqual(main(["--db", db, "promote", "--actor", "joshua", "--id", "climb",
                               "--to", "INDEPENDENTLY_VALIDATED", "--approved-by", "Joshua",
                               "--confirm", "wrong"]), 3)
        rc = main(["--db", db, "run", "--actor", "claude", "--claim", "climb", "--",
                   sys.executable, "-c", "print('hi')"])
        self.assertEqual(rc, 0)
        self.assertEqual(main(["--db", db, "verify"]), 0)
        led = Ledger(db)
        self.assertEqual(led.claim("climb")["rung"], "RUNTIME_VERIFIED")
        self.assertIn("Chain: INTACT", build_report(led))
        led.close()


if __name__ == "__main__":
    unittest.main()
