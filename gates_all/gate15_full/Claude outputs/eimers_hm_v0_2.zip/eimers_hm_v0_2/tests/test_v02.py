import json
import os
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from eimers_hm import actors  # noqa: E402
from eimers_hm.cli import main  # noqa: E402
from eimers_hm.ledger import Ledger  # noqa: E402
from eimers_hm.web import make_handler, render_claim, render_index  # noqa: E402

PW = "correct horse battery"


def reader_for(*answers):
    seq = list(answers)

    def r(_prompt):
        return seq.pop(0)
    return r


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.db = os.path.join(self.tmp, "t.sqlite")
        self.led = Ledger(self.db)
        self.led.add_claim("c1", "x <script>alert(1)</script> drops", "", "joshua")

    def tearDown(self):
        self.led.close()

    def register_joshua(self):
        actors.register(self.led, "joshua", "approver", "joshua", reader=reader_for(PW, PW))


class TestActors(Base):
    def test_first_approver_turns_on_strict(self):
        self.assertFalse(actors.strict(self.led))
        self.register_joshua()
        self.assertTrue(actors.strict(self.led))
        reg = actors.registry(self.led)
        self.assertNotIn(PW, json.dumps(reg))  # passphrase never stored

    def test_short_or_mismatched_passphrase(self):
        with self.assertRaises(actors.ApprovalError):
            actors.register(self.led, "j", "approver", "j", reader=reader_for("short", "short"))
        with self.assertRaises(actors.ApprovalError):
            actors.register(self.led, "j", "approver", "j", reader=reader_for(PW, PW + "x"))

    def test_authorize_and_wrong_passphrase(self):
        self.register_joshua()
        sig = actors.authorize(self.led, "joshua", {"a": 1}, reader=reader_for(PW))
        self.assertEqual(sig["actor"], "joshua")
        with self.assertRaises(actors.ApprovalError):
            actors.authorize(self.led, "joshua", {"a": 1}, reader=reader_for("wrong passphrase!"))

    def test_worker_and_unknown_cannot_approve(self):
        self.register_joshua()
        actors.register(self.led, "antigravity", "worker", "joshua", reader=reader_for(PW))
        with self.assertRaises(actors.ApprovalError):
            actors.authorize(self.led, "antigravity", {"a": 1}, reader=reader_for(PW))
        with self.assertRaises(actors.ApprovalError):
            actors.authorize(self.led, "claude", {"a": 1}, reader=reader_for(PW))

    def test_registry_change_needs_approver_in_strict(self):
        self.register_joshua()
        with self.assertRaises(actors.ApprovalError):
            actors.register(self.led, "claude", "approver", "claude",
                            reader=reader_for(PW, PW, PW))

    def test_signatures_verify_and_detect_tamper(self):
        self.register_joshua()
        payload = {"claim_id": "c1", "status": "OPEN", "reason": "r"}
        sig = actors.authorize(self.led, "joshua", payload, reader=reader_for(PW))
        self.led.set_status("c1", "OPEN", "r", "joshua", signature=sig)
        ok, bad, unsigned = actors.check_signatures(self.led, "joshua", reader=reader_for(PW))
        self.assertEqual((ok, bad), (1, []))
        # a forged signature (right shape, wrong key) is caught
        forged = dict(sig, sig="0" * 64)
        self.led.set_status("c1", "OPEN", "r2", "joshua", signature=forged)
        ok, bad, _ = actors.check_signatures(self.led, "joshua", reader=reader_for(PW))
        self.assertEqual(ok, 1)
        self.assertEqual(len(bad), 1)

    def test_no_terminal_means_no_approval(self):
        # Under the test runner stdin is not a TTY: the real prompt must refuse.
        self.register_joshua()
        if sys.stdin.isatty():
            self.skipTest("running in a terminal")
        with self.assertRaises(actors.ApprovalError):
            actors.authorize(self.led, "joshua", {"a": 1})

    def test_cli_promote_refused_without_terminal(self):
        self.register_joshua()
        self.led.add_evidence("c1", "code_review", True, {"note": "n"}, "claude")
        if sys.stdin.isatty():
            self.skipTest("running in a terminal")
        rc = main(["--db", self.db, "promote", "--actor", "joshua", "--id", "c1",
                   "--to", "LOCATED", "--approved-by", "Joshua",
                   "--confirm", "PROMOTE c1 TO LOCATED"])
        self.assertEqual(rc, 5)
        self.assertEqual(self.led.claim("c1")["rung"], "CLAIMED")

    def test_hold_never_needs_signature(self):
        self.register_joshua()
        rc = main(["--db", self.db, "status", "--actor", "antigravity", "--id", "c1",
                   "--status", "HOLD", "--reason", "check failed"])
        self.assertEqual(rc, 0)
        self.assertEqual(self.led.claim("c1")["status"], "HOLD")


class TestWeb(Base):
    def test_pages_escape_content(self):
        html_index = render_index(self.led)
        self.assertNotIn("<script>alert(1)</script>", html_index)
        self.assertIn("&lt;script&gt;", html_index)
        self.assertIn("Chain", html_index)
        self.assertNotIn("<script>alert", render_claim(self.led, "c1"))

    def test_server_read_only(self):
        from http.server import HTTPServer
        srv = HTTPServer(("127.0.0.1", 0), make_handler(self.db))
        port = srv.server_address[1]
        t = threading.Thread(target=srv.serve_forever, daemon=True)
        t.start()
        try:
            base = "http://127.0.0.1:%d" % port
            with urllib.request.urlopen(base + "/") as r:
                self.assertEqual(r.status, 200)
            with urllib.request.urlopen(base + "/claim/c1") as r:
                self.assertEqual(r.status, 200)
            with urllib.request.urlopen(base + "/api/state.json") as r:
                self.assertTrue(json.loads(r.read())["chain_ok"])
            req = urllib.request.Request(base + "/", data=b"x", method="POST")
            with self.assertRaises(urllib.error.HTTPError) as cm:
                urllib.request.urlopen(req)
            self.assertEqual(cm.exception.code, 405)
            with self.assertRaises(urllib.error.HTTPError) as cm:
                urllib.request.urlopen(base + "/claim/nope")
            self.assertEqual(cm.exception.code, 404)
        finally:
            srv.shutdown()
            srv.server_close()
        n_before = len(self.led.events())
        self.assertEqual(len(Ledger(self.db).events()), n_before)  # nothing written


if __name__ == "__main__":
    unittest.main()
