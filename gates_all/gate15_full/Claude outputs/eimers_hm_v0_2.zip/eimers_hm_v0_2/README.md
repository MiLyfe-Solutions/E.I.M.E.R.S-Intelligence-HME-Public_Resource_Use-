# E.I.M.E.R.S. HumanAI Mathematics - v0.2.0

A governed ledger for human + AI discovery. AI and code generate the work;
independent checkers judge it; a named human approves every step up the
evidence ladder; every change is a hash-chained, append-only event.

Standard library only. Python 3.9 or newer (tested on 3.9.25 and 3.13).
Run everything from this folder with `python3 -m eimers_hm`.

New in v0.2:

- **Signed approvals.** Register yourself as the approver once. After that,
  promoting, reopening, rejecting or correcting a claim needs your passphrase
  typed at a real terminal. An AI agent running commands has no terminal, so
  it cannot approve on your behalf. Putting a claim on HOLD never needs a
  passphrase.
- **Web screen.** A read-only page at http://127.0.0.1:8791 showing every
  claim, its rung, evidence and history. It listens on this Mac only and has
  no buttons that change anything.

## Upgrade from v0.1 (keeps your existing ledger)

Paste as one block:

```bash
cd ~/Downloads
unzip -oq eimers_hm_v0_2.zip
cp eimers_hm_v0/cpoq_ledger.sqlite eimers_hm_v0_2/cpoq_ledger.sqlite
cp -R eimers_hm_v0/receipts eimers_hm_v0_2/ 2>/dev/null
cd eimers_hm_v0_2
python3 -m unittest discover -s tests 2>&1 | grep -E "^(Ran|OK|FAILED)"
python3 -m eimers_hm --db cpoq_ledger.sqlite verify
```

Expect `Ran 37 tests`, `OK`, and `chain_ok: true`. The old folder stays as it
was, as a backup.

## Turn on signed approvals (once)

```bash
python3 -m eimers_hm --db cpoq_ledger.sqlite register-actor --actor joshua --name joshua --role approver
```

It asks for a passphrase twice (12 characters or more). Only a hash is
stored. Write the passphrase down somewhere safe: it cannot be recovered,
and without it no one can approve anything in this ledger.

From then on, approve as `--actor joshua`. Optional: register the AI
workers so the record shows their role (no passphrase needed):

```bash
python3 -m eimers_hm --db cpoq_ledger.sqlite register-actor --actor joshua --name antigravity --role worker
python3 -m eimers_hm --db cpoq_ledger.sqlite register-actor --actor joshua --name claude --role worker
```

Each of these asks for your passphrase, because changing who may do what is
itself an approval.

## Open the web screen

```bash
python3 -m eimers_hm --db cpoq_ledger.sqlite web
```

Then open http://127.0.0.1:8791 in your browser. Press Ctrl+C in the
terminal to stop it. Port 8791 is not on your reserved list; use `--port` to
pick another.

## Everyday commands (ready to paste)

```bash
python3 -m eimers_hm --db cpoq_ledger.sqlite list
python3 -m eimers_hm --db cpoq_ledger.sqlite verify
python3 -m eimers_hm --db cpoq_ledger.sqlite report --out report.md
python3 -m eimers_hm --db cpoq_ledger.sqlite actors
python3 -m eimers_hm --db cpoq_ledger.sqlite verify-signatures --actor joshua
```

## Templates (fill in the CAPITALS before pasting)

Add a claim:

```text
python3 -m eimers_hm --db cpoq_ledger.sqlite add-claim --actor joshua --id CLAIM_ID --statement "WHAT YOU CLAIM" --scope "EXACT SCOPE"
```

Judge a Lean build log:

```text
python3 -m eimers_hm --db cpoq_ledger.sqlite check-lean --actor joshua-mac --claim CLAIM_ID --log PATH/TO/Lean.log --exit-code-file PATH/TO/lean_exit_code.txt
```

Run any command and keep a receipt (everything after `--` is the command):

```text
python3 -m eimers_hm --db cpoq_ledger.sqlite run --actor joshua-mac --claim CLAIM_ID --runtime -- python3 YOUR_SCRIPT.py
```

Compare two independent results:

```text
python3 -m eimers_hm --db cpoq_ledger.sqlite check-replication --actor joshua --claim CLAIM_ID --a FILE_A --b FILE_B --impl-a "WHO MADE A" --impl-b "WHO MADE B"
```

Promote (asks for your passphrase once signing is on):

```text
python3 -m eimers_hm --db cpoq_ledger.sqlite promote --actor joshua --id CLAIM_ID --to RUNG --approved-by "Joshua Eimers" --confirm "PROMOTE CLAIM_ID TO RUNG"
```

Rungs: `LOCATED`, `CODE_CONFIRMED`, `SCHEMA_VERIFIED`, `RUNTIME_VERIFIED`,
`INDEPENDENTLY_VALIDATED`.

Put on HOLD, or reopen (reopen asks for your passphrase):

```text
python3 -m eimers_hm --db cpoq_ledger.sqlite status --actor ANY_NAME --id CLAIM_ID --status HOLD --reason "WHY"
python3 -m eimers_hm --db cpoq_ledger.sqlite status --actor joshua --id CLAIM_ID --status OPEN --reason "WHY"
```

End a session:

```text
python3 -m eimers_hm --db cpoq_ledger.sqlite handoff --actor joshua --summary "WHAT HAPPENED" --open "WHAT IS LEFT" --next "NEXT SAFE STEP"
```

## The evidence ladder

| Rung | Supported by passing evidence of kind |
|---|---|
| LOCATED | located, receipt, code_review, lean, replication, schema |
| CODE_CONFIRMED | code_review, receipt, lean, replication |
| SCHEMA_VERIFIED | schema |
| RUNTIME_VERIFIED | lean pass, or a receipt marked --runtime with exit 0 |
| INDEPENDENTLY_VALIDATED | replication with two different implementations, claim already at CODE_CONFIRMED |

Rules the tool enforces:

- Promotion needs passing evidence, a named approver and the exact phrase
  `PROMOTE <id> TO <RUNG>`; with signing on, also the approver's passphrase.
- A failed check puts the claim on HOLD automatically (fail closed).
- HOLD, REJECTED and SUPERSEDED claims cannot be promoted.
- A founder override (`--override-reason`) skips only the evidence rule; it is
  recorded and listed in every report.
- Corrections keep the original statement, the reason and who changed it.
- The overclaim guard flags proof wording below RUNTIME_VERIFIED,
  "independent" wording below INDEPENDENTLY_VALIDATED, and any statement that
  reads as settling a famous open problem without a stated scope.
- The ledger refuses UPDATE and DELETE; `verify` recomputes every hash.

## Limits (honest list)

- Signing is local: it proves the approver's passphrase was typed at this
  Mac's terminal. It is not yet tied to the E.I.M.E.R.S. sign-in.
- Promotions made before signing was turned on stay in the record, shown as
  "unsigned".
- If you change your passphrase by registering again, `verify-signatures`
  checks against the new one; older signatures will show as not matching.
- The hash chain shows tampering inside the file. Someone who rewrites the
  whole file can rebuild a valid chain; keep the latest head hash somewhere
  else (E.I.M.E.R.S. Task & Evidence) to close that gap.
- Checkers so far: Lean logs, receipts and two-file replication.
- The tool does not discover anything. It makes results trustworthy and
  repeatable.
