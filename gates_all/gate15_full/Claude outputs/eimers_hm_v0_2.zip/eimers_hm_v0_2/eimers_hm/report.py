"""Markdown report built only from the ledger."""

from . import RUNGS
from .gate import guard


def _short(h):
    return h[:12] if h else ""


def build_report(ledger, title="E.I.M.E.R.S. HumanAI Mathematics - ledger report"):
    st = ledger.state()
    ok, bad_seq, n = ledger.verify_chain()
    claims = sorted(st["claims"].values(), key=lambda c: c["id"])
    lines = ["# %s" % title, ""]
    lines.append("Chain: %s, %d events%s." % (
        "INTACT" if ok else "BROKEN", n,
        "" if ok else " (first bad event %s)" % bad_seq))
    lines.append("")

    # counts by rung and status
    lines.append("| Rung | Open | HOLD | Rejected |")
    lines.append("| --- | --- | --- | --- |")
    for r in RUNGS:
        row = [c for c in claims if c["rung"] == r]
        lines.append("| %s | %d | %d | %d |" % (
            r, sum(1 for c in row if c["status"] == "OPEN"),
            sum(1 for c in row if c["status"] == "HOLD"),
            sum(1 for c in row if c["status"] == "REJECTED")))
    lines.append("")

    flagged = [(c, guard(c["statement"], c["rung"])) for c in claims]
    flagged = [(c, f) for c, f in flagged if f]
    if flagged:
        lines.append("## Overclaim flags")
        lines.append("")
        for c, f in flagged:
            lines.append("- **%s**: %s" % (c["id"], "; ".join(f)))
        lines.append("")

    overrides = [(c, o) for c in claims for o in c["overrides"]]
    if overrides:
        lines.append("## Founder overrides")
        lines.append("")
        for c, o in overrides:
            lines.append("- **%s** to %s by %s at %s: %s" % (
                c["id"], o["to"], o["actor"], o["ts"], o["reason"]))
        lines.append("")

    lines.append("## Claims")
    lines.append("")
    for c in claims:
        lines.append("### %s - %s / %s" % (c["id"], c["rung"], c["status"]))
        lines.append("")
        lines.append(c["statement"])
        if c["scope"]:
            lines.append("")
            lines.append("Scope: %s" % c["scope"])
        if c["corrections"]:
            lines.append("")
            for k in c["corrections"]:
                lines.append("- Corrected at %s by %s: was \"%s\". Reason: %s" % (
                    k["ts"], k["actor"], k["original"], k["reason"]))
        if c["evidence"]:
            lines.append("")
            for ev in c["evidence"]:
                d = ev.get("details") or {}
                note = d.get("note") or "; ".join(d.get("reasons", [])) or ""
                lines.append("- %s %s (event %d, %s)%s" % (
                    "PASS" if ev["passed"] else "FAIL", ev["kind"], ev["seq"],
                    _short(ev["hash"]), (": " + note) if note else ""))
        lines.append("")

    if st["handoffs"]:
        h = st["handoffs"][-1]
        lines.append("## Latest handoff")
        lines.append("")
        lines.append("By %s at %s." % (h["actor"], h["ts"]))
        for key, label in (("summary", "Summary"), ("open_tasks", "Open"),
                           ("do_not_repeat", "Do not repeat"),
                           ("next_safe_action", "Next safe action")):
            val = h.get(key)
            if val:
                if isinstance(val, list):
                    lines.append("- %s: %s" % (label, "; ".join(val)))
                else:
                    lines.append("- %s: %s" % (label, val))
        lines.append("")
    return "\n".join(lines)
