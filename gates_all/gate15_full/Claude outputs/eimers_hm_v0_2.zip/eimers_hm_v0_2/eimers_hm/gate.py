"""Promotion gate and overclaim guard.

A claim moves up the evidence ladder only when (1) passing evidence of the
right kind is attached, (2) a named human approves with the exact
confirmation phrase, and (3) the claim is not on HOLD or rejected.
A founder override can bypass (1); it is recorded with a reason and shown
in every report.
"""

import re

from . import RUNGS, rung_index

# Which passing evidence kinds can support each rung.
SUPPORTS = {
    "CLAIMED": set(),
    "LOCATED": {"located", "receipt", "code_review", "lean", "replication", "schema"},
    "CODE_CONFIRMED": {"code_review", "receipt", "lean", "replication"},
    "SCHEMA_VERIFIED": {"schema"},
    "RUNTIME_VERIFIED": {"lean", "runtime_receipt"},
    "INDEPENDENTLY_VALIDATED": {"replication_independent"},
}


def confirmation_phrase(claim_id, to_rung):
    return "PROMOTE %s TO %s" % (claim_id, to_rung)


def _evidence_tags(ev):
    """Tags a single passing evidence record can count as."""
    if not ev.get("passed"):
        return set()
    k = ev["kind"]
    tags = {k}
    d = ev.get("details") or {}
    if k == "receipt" and d.get("exit_code") == 0 and d.get("runtime"):
        tags.add("runtime_receipt")
    if k == "replication" and d.get("independent"):
        tags.add("replication_independent")
    return tags


def supporting_evidence(claim, to_rung):
    need = SUPPORTS[to_rung]
    return [ev for ev in claim["evidence"] if _evidence_tags(ev) & need]


def check_promotion(claim, to_rung, approved_by, phrase, override_reason=None):
    """Return a list of blocking reasons (empty list = allowed)."""
    reasons = []
    if to_rung not in RUNGS:
        return ["unknown rung %s" % to_rung]
    if rung_index(to_rung) <= rung_index(claim["rung"]):
        reasons.append("claim is already at %s" % claim["rung"])
    if claim["status"] in ("HOLD", "REJECTED", "SUPERSEDED"):
        reasons.append("claim status is %s; clear it before promoting" % claim["status"])
    if not approved_by:
        reasons.append("a named human approver is required")
    if phrase != confirmation_phrase(claim["id"], to_rung):
        reasons.append("confirmation phrase must be exactly: %s"
                       % confirmation_phrase(claim["id"], to_rung))
    if to_rung == "INDEPENDENTLY_VALIDATED" and rung_index(claim["rung"]) < rung_index("CODE_CONFIRMED"):
        reasons.append("independent validation needs the claim at CODE_CONFIRMED or higher first")
    if not supporting_evidence(claim, to_rung) and not override_reason:
        reasons.append("no passing evidence that supports %s (needs one of: %s)"
                       % (to_rung, ", ".join(sorted(SUPPORTS[to_rung]))))
    return reasons


# ---- overclaim guard ---------------------------------------------------------

# (pattern, minimum rung, message)
WORDING_RULES = [
    (r"\b(prove[sdn]?|proving|proof|theorem|verified|certif(y|ies|ied))\b",
     "RUNTIME_VERIFIED", "proof wording needs RUNTIME_VERIFIED or higher"),
    (r"\bindependent(ly)?\b", "INDEPENDENTLY_VALIDATED",
     "'independent' wording needs INDEPENDENTLY_VALIDATED"),
]

# Famous open problems: a statement that says one is settled, with no
# narrowing scope, is flagged whatever its rung. Extend this list per field.
OPEN_PROBLEMS = ["collatz", "riemann hypothesis", "goldbach", "twin prime"]
SETTLED_WORDS = r"\b(prove[sdn]?|proof of|solve[sd]?|resolve[sd]?|is true|settled)\b"
SCOPE_WORDS = r"\b(segment|famil(y|ies)|lots?|residues?|below|up to|for all n ?[<≤]|case|bound|climb|exit|reduction|implies|if )\b"


def guard(statement, rung):
    """Return overclaim flags for a statement held at a given rung."""
    flags = []
    s = statement.lower()
    for pat, min_rung, msg in WORDING_RULES:
        if re.search(pat, s) and rung_index(rung) < rung_index(min_rung):
            flags.append(msg)
    for name in OPEN_PROBLEMS:
        if name in s and re.search(SETTLED_WORDS, s) and not re.search(SCOPE_WORDS, s):
            flags.append("reads as settling the %s problem in general; state the exact scope"
                         % name)
    return flags
