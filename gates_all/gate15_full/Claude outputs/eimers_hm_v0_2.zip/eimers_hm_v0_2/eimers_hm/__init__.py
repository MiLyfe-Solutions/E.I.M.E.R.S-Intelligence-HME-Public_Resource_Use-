"""E.I.M.E.R.S. HumanAI Mathematics - governed ledger for human+AI discovery.

v0: claims, evidence rungs, hash-chained receipts, Lean and replication
checkers, overclaim guard, human-gated promotion, handoffs, reports.
Standard library only; Python 3.9+.
"""

__version__ = "0.2.0"

RUNGS = [
    "CLAIMED",
    "LOCATED",
    "CODE_CONFIRMED",
    "SCHEMA_VERIFIED",
    "RUNTIME_VERIFIED",
    "INDEPENDENTLY_VALIDATED",
]

# Terminal states that are not rungs: a claim can be put on HOLD or rejected.
STATUSES = ["OPEN", "HOLD", "REJECTED", "SUPERSEDED"]


def rung_index(rung):
    if rung not in RUNGS:
        raise ValueError("unknown rung: %s" % rung)
    return RUNGS.index(rung)
