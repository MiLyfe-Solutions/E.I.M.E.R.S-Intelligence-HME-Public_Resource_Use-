"""Actor registry and passphrase-signed approvals.

Roles:
  approver - may promote, reopen, reject, supersede and correct claims.
  worker   - may add claims, evidence, receipts, handoffs, and put claims on HOLD.

Once any approver is registered the ledger is in STRICT mode: gated actions
need a registered approver who types their passphrase at an interactive
terminal. The passphrase never leaves the machine; the ledger stores only a
salt and a hash of the derived key. Each gated event carries an HMAC
signature that the approver can re-check later with `verify-signatures`.

Why an interactive terminal: an AI agent running commands has no terminal
to type into, so it cannot sign an approval on a human's behalf.
"""

import getpass
import hashlib
import hmac
import os
import sys

from .ledger import canonical

ITERATIONS = 200000
ROLES = ("approver", "worker")
GATED = ("promoted", "corrected", "status_open", "status_rejected", "status_superseded")


class ApprovalError(Exception):
    pass


def derive_key(passphrase, salt_hex, iterations=ITERATIONS):
    return hashlib.pbkdf2_hmac("sha256", passphrase.encode("utf-8"),
                               bytes.fromhex(salt_hex), iterations)


def verifier_of(key):
    return hashlib.sha256(b"eimers-hm-verifier|" + key).hexdigest()


def sign(key, payload):
    return hmac.new(key, canonical(payload).encode("utf-8"), hashlib.sha256).hexdigest()


def registry(ledger):
    """Latest registration per actor, replayed from the ledger."""
    reg = {}
    for e in ledger.events():
        if e["kind"] == "actor_registered":
            p = e["payload"]
            reg[p["actor"]] = dict(p, seq=e["seq"])
    return reg


def strict(ledger):
    return any(r["role"] == "approver" for r in registry(ledger).values())


def read_passphrase(prompt, reader=None):
    """Read from an interactive terminal only. Tests pass a reader."""
    if reader is not None:
        return reader(prompt)
    if not sys.stdin.isatty():
        raise ApprovalError("approval needs an interactive terminal; "
                            "this command was not run by a person at a keyboard")
    return getpass.getpass(prompt)


def register(ledger, actor, role, registered_by, reader=None):
    if role not in ROLES:
        raise ValueError("role must be one of %s" % ", ".join(ROLES))
    reg = registry(ledger)
    payload = {"actor": actor, "role": role}
    if role == "approver":
        p1 =read_passphrase("New passphrase for %s: " % actor, reader)
        p2 = read_passphrase("Repeat passphrase: ", reader)
        if p1 != p2:
            raise ApprovalError("passphrases do not match")
        if len(p1) < 12:
            raise ApprovalError("passphrase must be at least 12 characters")
        salt = os.urandom(16).hex()
        key = derive_key(p1, salt)
        payload.update({"salt": salt, "iterations": ITERATIONS, "verifier": verifier_of(key)})
    if strict(ledger):
        # In strict mode, any registry change is itself an approval.
        sig = authorize(ledger, registered_by, payload, reader)
        payload["signature"] = sig
    return ledger.append("actor_registered", registered_by, payload)


def authorize(ledger, actor, payload, reader=None):
    """Check the actor may approve and return a signature block, or raise."""
    reg = registry(ledger)
    if actor not in reg:
        raise ApprovalError("actor '%s' is not registered" % actor)
    r = reg[actor]
    if r["role"] != "approver":
        raise ApprovalError("actor '%s' is a %s; only an approver can do this" % (actor, r["role"]))
    pw = read_passphrase("Passphrase for %s: " % actor, reader)
    key = derive_key(pw, r["salt"], r.get("iterations", ITERATIONS))
    if not hmac.compare_digest(verifier_of(key), r["verifier"]):
        raise ApprovalError("wrong passphrase for %s" % actor)
    return {"actor": actor, "alg": "pbkdf2-sha256/hmac-sha256", "sig": sign(key, payload),
            "registration_seq": r["seq"]}


def check_signatures(ledger, actor, reader=None):
    """Re-check every signature made by `actor`. Returns (ok_count, bad_seqs, unsigned_seqs)."""
    reg = registry(ledger)
    if actor not in reg or reg[actor]["role"] != "approver":
        raise ApprovalError("actor '%s' is not a registered approver" % actor)
    pw = read_passphrase("Passphrase for %s: " % actor, reader)
    latest = reg[actor]
    if not hmac.compare_digest(
            verifier_of(derive_key(pw, latest["salt"], latest.get("iterations", ITERATIONS))),
            latest["verifier"]):
        raise ApprovalError("wrong passphrase for %s" % actor)
    regs = {}
    for e in ledger.events():
        if e["kind"] == "actor_registered" and e["payload"]["actor"] == actor \
                and e["payload"]["role"] == "approver":
            regs[e["seq"]] = e["payload"]
    ok, bad, unsigned = 0, [], []
    for e in ledger.events():
        p = dict(e["payload"])
        sig = p.pop("signature", None)
        if sig is None:
            if e["actor"] == actor and e["kind"] in ("promoted", "corrected", "status_changed"):
                unsigned.append(e["seq"])
            continue
        if sig.get("actor") != actor:
            continue
        r = regs.get(sig.get("registration_seq"))
        if r is None:
            bad.append(e["seq"])
            continue
        key = derive_key(pw, r["salt"], r.get("iterations", ITERATIONS))
        if hmac.compare_digest(sign(key, p), sig["sig"]):
            ok += 1
        else:
            bad.append(e["seq"])
    return ok, bad, unsigned
