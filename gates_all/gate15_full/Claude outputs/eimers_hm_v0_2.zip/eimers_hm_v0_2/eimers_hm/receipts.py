"""Run a command and keep a receipt: what went in, what came out, exit code.

The command runs without a shell (no pipes, no globbing) so the recorded
command is exactly what ran. Output is saved next to the ledger so any
checker can re-read it later.
"""

import os
import subprocess
import time

from .checkers import sha256_bytes, sha256_file
from .ledger import canonical


def run_with_receipt(cmd, store_dir, cwd=None, inputs=(), timeout=None):
    if not cmd:
        raise ValueError("empty command")
    input_hashes = {}
    for p in inputs:
        input_hashes[os.path.abspath(p)] = sha256_file(p)
    t0 = time.time()
    try:
        proc = subprocess.run(cmd, cwd=cwd, capture_output=True, timeout=timeout)
        exit_code, out, err = proc.returncode, proc.stdout, proc.stderr
        timed_out = False
    except subprocess.TimeoutExpired as exc:
        exit_code, out, err = -1, exc.stdout or b"", exc.stderr or b""
        timed_out = True
    except FileNotFoundError as exc:
        exit_code, out, err = 127, b"", str(exc).encode()
        timed_out = False
    duration = round(time.time() - t0, 3)

    body = {
        "cmd": list(cmd),
        "cwd": os.path.abspath(cwd or os.getcwd()),
        "inputs": input_hashes,
        "exit_code": exit_code,
        "timed_out": timed_out,
        "stdout_sha256": sha256_bytes(out),
        "stderr_sha256": sha256_bytes(err),
        "duration_s": duration,
    }
    receipt_id = sha256_bytes(canonical(body).encode())[:16]
    rdir = os.path.join(store_dir, "receipts", receipt_id)
    os.makedirs(rdir, exist_ok=True)
    with open(os.path.join(rdir, "stdout.txt"), "wb") as f:
        f.write(out)
    with open(os.path.join(rdir, "stderr.txt"), "wb") as f:
        f.write(err)
    body["receipt_id"] = receipt_id
    body["stdout_path"] = os.path.join(rdir, "stdout.txt")
    body["stderr_path"] = os.path.join(rdir, "stderr.txt")
    return body
