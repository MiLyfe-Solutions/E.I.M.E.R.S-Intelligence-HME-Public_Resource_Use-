"""Read-only web screen for the ledger.

Binds to 127.0.0.1 only, so nothing on the network can reach it. It has no
forms and no write routes: every change still goes through the command line,
where approvals need a person at the keyboard. The ledger is re-read on every
request, so the page always shows the current file.
"""

import html
import json
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import unquote

from . import RUNGS, __version__, actors
from .gate import guard
from .ledger import Ledger
from .report import build_report

HOST = "127.0.0.1"

CSS = """
:root{--bg:#f7f7f5;--card:#fff;--ink:#1d1d1b;--quiet:#6b6b66;--line:#e2e1dc;
--ok:#1f7a3f;--hold:#a15c00;--bad:#b42318;--accent:#2b5fd9;}
@media (prefers-color-scheme: dark){:root{--bg:#141413;--card:#1e1e1c;--ink:#ecebe6;
--quiet:#a3a29c;--line:#34332f;--ok:#5cc184;--hold:#e0a14a;--bad:#f07a6f;--accent:#7aa2ff;}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);
font:15px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
main{max-width:1100px;margin:0 auto;padding:24px 16px}
a{color:var(--accent);text-decoration:none}a:hover{text-decoration:underline}
h1{font-size:22px;margin:0 0 4px}h2{font-size:17px;margin:28px 0 8px}
.sub{color:var(--quiet);margin-bottom:20px}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:16px;margin:12px 0}
table{width:100%;border-collapse:collapse;background:var(--card);border:1px solid var(--line);border-radius:10px;overflow:hidden}
th,td{text-align:left;padding:8px 10px;border-bottom:1px solid var(--line);vertical-align:top}
th{font-size:12px;color:var(--quiet);text-transform:uppercase;letter-spacing:.04em}
.pill{display:inline-block;padding:1px 8px;border-radius:999px;font-size:12px;border:1px solid var(--line)}
.ok{color:var(--ok)}.hold{color:var(--hold)}.bad{color:var(--bad)}
.mono{font-family:ui-monospace,Menlo,monospace;font-size:13px;word-break:break-all}
.ladder{display:flex;gap:6px;flex-wrap:wrap}.ladder span{padding:2px 8px;border-radius:6px;border:1px solid var(--line);font-size:12px;color:var(--quiet)}
.ladder span.on{border-color:var(--accent);color:var(--ink);font-weight:600}
pre{white-space:pre-wrap;background:var(--card);border:1px solid var(--line);border-radius:10px;padding:16px}
"""


def esc(s):
    return html.escape("" if s is None else str(s))


def page(title, body):
    return ("<!doctype html><html lang='en'><head><meta charset='utf-8'>"
            "<meta name='viewport' content='width=device-width,initial-scale=1'>"
            "<title>%s</title><style>%s</style></head><body><main>%s"
            "<p class='sub' style='margin-top:32px'>E.I.M.E.R.S. HumanAI Mathematics v%s "
            "&middot; read-only &middot; changes go through the command line</p>"
            "</main></body></html>") % (esc(title), CSS, body, esc(__version__))


def status_class(status):
    return {"OPEN": "ok", "HOLD": "hold", "REJECTED": "bad", "SUPERSEDED": "bad"}.get(status, "")


def render_index(led):
    st = led.state()
    ok, bad, n = led.verify_chain()
    head = led.last_hash()
    reg = actors.registry(led)
    strict = any(r["role"] == "approver" for r in reg.values())
    claims = sorted(st["claims"].values(), key=lambda c: c["id"])
    parts = ["<h1>Claims ledger</h1>",
             "<div class='sub'>%s</div>" % esc(led.path)]
    parts.append("<div class='card'><b class='%s'>Chain %s</b> &middot; %d events &middot; "
                 "head <span class='mono'>%s</span><br>Approvals: <b>%s</b>%s</div>" % (
                     "ok" if ok else "bad", "INTACT" if ok else "BROKEN at event %s" % bad, n,
                     esc(head), "signed (strict mode)" if strict else "unsigned (no approver registered)",
                     "" if strict else " &middot; run <span class='mono'>register-actor</span> to turn on signing"))
    parts.append("<table><tr><th>Claim</th><th>Rung</th><th>Status</th><th>Statement</th></tr>")
    for c in claims:
        flags = guard(c["statement"], c["rung"])
        parts.append("<tr><td><a href='/claim/%s'>%s</a></td><td>%s</td>"
                     "<td class='%s'>%s</td><td>%s%s</td></tr>" % (
                         esc(c["id"]), esc(c["id"]), esc(c["rung"].replace("_", " ").title()),
                         status_class(c["status"]), esc(c["status"]), esc(c["statement"]),
                         " <span class='pill bad'>overclaim</span>" if flags else ""))
    parts.append("</table>")
    if st["handoffs"]:
        h = st["handoffs"][-1]
        parts.append("<h2>Latest handoff</h2><div class='card'><b>%s</b> &middot; %s<br>%s" % (
            esc(h["actor"]), esc(h["ts"]), esc(h.get("summary"))))
        if h.get("next_safe_action"):
            parts.append("<br>Next: %s" % esc(h["next_safe_action"]))
        parts.append("</div>")
    parts.append("<p><a href='/report'>Full report</a> &middot; <a href='/api/state.json'>JSON</a></p>")
    return page("Claims ledger", "".join(parts))


def render_claim(led, claim_id):
    c = led.claim(claim_id)
    ladder = "".join("<span class='%s'>%s</span>" % ("on" if r == c["rung"] else "",
                                                     esc(r.replace("_", " ").title())) for r in RUNGS)
    parts = ["<p><a href='/'>&larr; All claims</a></p>",
             "<h1>%s</h1>" % esc(c["id"]),
             "<div class='ladder'>%s</div>" % ladder,
             "<div class='card'><b class='%s'>%s</b><br>%s" % (
                 status_class(c["status"]), esc(c["status"]), esc(c["statement"]))]
    if c["scope"]:
        parts.append("<br><span class='sub'>Scope: %s</span>" % esc(c["scope"]))
    parts.append("</div>")
    flags = guard(c["statement"], c["rung"])
    if flags:
        parts.append("<div class='card bad'>Overclaim: %s</div>" % esc("; ".join(flags)))

    parts.append("<h2>Evidence</h2>")
    if not c["evidence"]:
        parts.append("<p class='sub'>None yet.</p>")
    else:
        parts.append("<table><tr><th>Event</th><th>Result</th><th>Kind</th><th>Details</th></tr>")
        for ev in c["evidence"]:
            d = ev.get("details") or {}
            bits = []
            if d.get("note"):
                bits.append(esc(d["note"]))
            if d.get("reasons"):
                bits.append("<span class='bad'>%s</span>" % esc("; ".join(d["reasons"])))
            if ev["kind"] == "lean":
                bits.append("exit %s &middot; %s theorem(s) &middot; axioms: %s" % (
                    esc(d.get("exit_code")), esc(d.get("theorems")),
                    esc(", ".join(d.get("axioms_used", [])) or "none")))
                if d.get("log_sha256"):
                    bits.append("<span class='mono'>log %s</span>" % esc(d["log_sha256"]))
            if ev["kind"] == "replication":
                bits.append("<span class='mono'>%s vs %s</span>" % (
                    esc(str(d.get("sha256_a", ""))[:16]), esc(str(d.get("sha256_b", ""))[:16])))
            if ev["kind"] == "receipt" and d.get("cmd"):
                bits.append("<span class='mono'>%s</span> &middot; exit %s" % (
                    esc(" ".join(d["cmd"])), esc(d.get("exit_code"))))
            parts.append("<tr><td>%d</td><td class='%s'>%s</td><td>%s</td><td>%s</td></tr>" % (
                ev["seq"], "ok" if ev["passed"] else "bad", "PASS" if ev["passed"] else "FAIL",
                esc(ev["kind"]), "<br>".join(bits)))
        parts.append("</table>")

    parts.append("<h2>History</h2><table><tr><th>Event</th><th>When</th><th>Who</th><th>What</th></tr>")
    for h in c["history"]:
        what = h["event"]
        if what == "promoted":
            what = "promoted %s &rarr; %s, approved by %s" % (esc(h["frm"]), esc(h["to"]),
                                                            esc(h.get("approved_by")))
            what += " &middot; <span class='ok'>signed</span>" if h.get("signed_by") else \
                " &middot; <span class='hold'>unsigned</span>"
            if h.get("override"):
                what += " &middot; <span class='hold'>override: %s</span>" % esc(h["override"])
        elif what == "status":
            what = "status &rarr; %s: %s" % (esc(h["status"]), esc(h.get("reason")))
        parts.append("<tr><td>%d</td><td>%s</td><td>%s</td><td>%s</td></tr>" % (
            h["seq"], esc(h["ts"]), esc(h["actor"]), what))
    parts.append("</table>")
    for k in c["corrections"]:
        parts.append("<div class='card'>Corrected by %s at %s. Was: \"%s\". Reason: %s</div>" % (
            esc(k["actor"]), esc(k["ts"]), esc(k["original"]), esc(k["reason"])))
    return page(c["id"], "".join(parts))


def make_handler(db_path):
    class Handler(BaseHTTPRequestHandler):
        def _send(self, code, body, ctype="text/html; charset=utf-8"):
            data = body.encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):
            led = Ledger(db_path)
            try:
                path = unquote(self.path.split("?", 1)[0])
                if path == "/":
                    self._send(200, render_index(led))
                elif path.startswith("/claim/"):
                    try:
                        self._send(200, render_claim(led, path[len("/claim/"):]))
                    except KeyError:
                        self._send(404, page("Not found", "<p>No such claim.</p>"))
                elif path == "/report":
                    self._send(200, page("Report", "<p><a href='/'>&larr; All claims</a></p><pre>%s</pre>"
                                         % esc(build_report(led))))
                elif path == "/api/state.json":
                    st = led.state()
                    ok, bad, n = led.verify_chain()
                    self._send(200, json.dumps({"chain_ok": ok, "events": n, "head": led.last_hash(),
                                                "claims": st["claims"]}, indent=2, default=str),
                               "application/json")
                else:
                    self._send(404, page("Not found", "<p>Not found.</p>"))
            finally:
                led.close()

        def do_POST(self):
            self._send(405, page("Read-only", "<p>This screen is read-only.</p>"))

        do_PUT = do_DELETE = do_PATCH = do_POST

        def log_message(self, fmt, *args):
            pass

    return Handler


def serve(db_path, port):
    import os
    if not os.path.isfile(db_path):
        raise ValueError("no ledger file at %s" % db_path)
    Ledger(db_path).close()  # fail early if the file is not a ledger
    httpd = HTTPServer((HOST, port), make_handler(db_path))
    print("E.I.M.E.R.S. HumanAI Mathematics: http://%s:%d  (Ctrl+C to stop)" % (HOST, port))
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
