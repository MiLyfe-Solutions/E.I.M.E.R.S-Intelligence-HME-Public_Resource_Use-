"""Independent checkers. Each returns a plain dict with 'passed' and 'reasons'.

The checkers never trust the generator: they read the generator's output
(a Lean log, two result files) and decide pass or fail from that alone.
"""

import hashlib
import re

DEFAULT_ALLOWED_AXIOMS = ("propext", "Quot.sound", "Classical.choice")

AXIOM_LINE = re.compile(r"'([^']+)' depends on axioms: \[([^\]]*)\]")
NO_AXIOM_LINE = re.compile(r"'([^']+)' does not depend on any axioms")
ERROR_LINE = re.compile(r"(^|\s)error(:|\b)", re.IGNORECASE)
SORRY_WARN = re.compile(r"declaration uses 'sorry'")


def check_lean(log_text, exit_code, allowed_axioms=DEFAULT_ALLOWED_AXIOMS,
               require_axioms=True):
    """Judge a Lean / lake build from its log and exit code.

    Pass requires: exit code 0, no error lines, no 'sorry' warnings, no
    sorryAx, every reported axiom in the allowed set, and (by default) at
    least one '#print axioms' result so the absence of sorry is shown,
    not assumed.
    """
    reasons = []
    axioms = {}
    for m in AXIOM_LINE.finditer(log_text):
        names = [a.strip() for a in m.group(2).split(",") if a.strip()]
        axioms[m.group(1)] = names
    for m in NO_AXIOM_LINE.finditer(log_text):
        axioms[m.group(1)] = []

    errors = [ln.strip() for ln in log_text.splitlines() if ERROR_LINE.search(ln)]
    sorry_warnings = [ln.strip() for ln in log_text.splitlines() if SORRY_WARN.search(ln)]

    if exit_code != 0:
        reasons.append("exit code %s (must be 0)" % exit_code)
    if errors:
        reasons.append("%d error line(s) in log" % len(errors))
    if sorry_warnings:
        reasons.append("%d 'sorry' warning(s)" % len(sorry_warnings))
    used = set()
    for names in axioms.values():
        used.update(names)
    if "sorryAx" in used:
        reasons.append("sorryAx appears in axioms")
    extra = sorted(used - set(allowed_axioms) - {"sorryAx"})
    if extra:
        reasons.append("axioms outside allowed set: %s" % ", ".join(extra))
    if require_axioms and not axioms:
        reasons.append("no '#print axioms' output found; cannot show absence of sorry")

    return {
        "checker": "lean",
        "passed": not reasons,
        "exit_code": exit_code,
        "theorems": len(axioms),
        "axioms": axioms,
        "axioms_used": sorted(used),
        "allowed_axioms": list(allowed_axioms),
        "error_lines": errors[:20],
        "reasons": reasons,
    }


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _normalized(path):
    with open(path, "rb") as f:
        lines = [ln.strip() for ln in f.read().splitlines() if ln.strip()]
    return b"\n".join(sorted(lines)) + b"\n"


def check_replication(path_a, path_b, impl_a, impl_b, sort_lines=False):
    """Two results produced by two implementations must match.

    'impl_a' and 'impl_b' name the implementations. They must differ: the same
    code run twice is a rerun, not an independent replication.
    """
    reasons = []
    if sort_lines:
        ha, hb = sha256_bytes(_normalized(path_a)), sha256_bytes(_normalized(path_b))
        mode = "sorted-lines"
    else:
        ha, hb = sha256_file(path_a), sha256_file(path_b)
        mode = "byte-exact"
    if ha != hb:
        reasons.append("results differ (%s): %s vs %s" % (mode, ha[:12], hb[:12]))
    independent = bool(impl_a) and bool(impl_b) and impl_a.strip() != impl_b.strip()
    if not independent:
        reasons.append("implementations not distinct; this is a rerun, not a replication")
    return {
        "checker": "replication",
        "passed": not reasons,
        "independent": independent,
        "mode": mode,
        "sha256_a": ha,
        "sha256_b": hb,
        "impl_a": impl_a,
        "impl_b": impl_b,
        "reasons": reasons,
    }
